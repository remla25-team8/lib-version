# lib-version

Small utility that lets any component ask **“what version am I running?”**:

```python
from lib_version import get_version
print(get_version())  # 0.1.0
```
