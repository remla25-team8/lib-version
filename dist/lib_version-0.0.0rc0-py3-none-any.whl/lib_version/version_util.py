"""Backward‑compat shim for assignment tests."""
from lib_version import get_version as get
